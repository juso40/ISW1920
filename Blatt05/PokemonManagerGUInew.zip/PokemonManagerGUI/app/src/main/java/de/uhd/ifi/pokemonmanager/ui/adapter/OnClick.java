package de.uhd.ifi.pokemonmanager.ui.adapter;

public interface OnClick {
    void onPositionClicked(int position);
}

package de.uhd.ifi.pokemonmanager.ui.adapter.singleSelection;

public interface SingleSelectionListener<T> {
    void currentSelected(T element);
}

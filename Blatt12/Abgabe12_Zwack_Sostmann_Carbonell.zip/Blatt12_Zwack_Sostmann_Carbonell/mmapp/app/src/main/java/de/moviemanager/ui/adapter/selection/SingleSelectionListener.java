package de.moviemanager.ui.adapter.selection;

public interface SingleSelectionListener<T> {
    void currentSelected(T element);
}
